
# Design Document

Write your design doc here.

Use the template: `docs/templates/design-doc.md`.
