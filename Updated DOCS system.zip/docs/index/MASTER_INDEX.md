
# Master Index

Single source of truth. The agent starts here.

## Project
<project name>

## Active Phase
- (set by agent)

## Active Sprint
- (set by agent)

## In Progress
- (none)

## Phases
- (created by agent)

## Sprints
- (created by agent)

## Decision Log
- [DECISION_LOG](../decisions/DECISION_LOG.md)

## Operating Rules

- Work only on items listed in the active sprint
- No new work without an ID + file
- If docs conflict, MASTER_INDEX wins
