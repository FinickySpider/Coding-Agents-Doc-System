
# Roadmap

Keep this file lightweight. Details live in phases and sprints.

## Milestones
- (fill in from the design)

## Notes
- Strategic changes should be recorded as ADRs.
